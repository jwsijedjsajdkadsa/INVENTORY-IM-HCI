##########################################################################
#   0.0   -   General Information
##########################################################################
The loader can be detected and blocked by your antivirus. THIS IS A FALSE POSITIVE AND YOU ARE ADVISED TO DISABLE / UNINSTALL IT WHEN USING THE KEYGEN

THIS KEYGEN DOES NOT ACTIVATE ANY COPY OF MICROSOT PRODUCTS IN ANY WAY. ITS ONLY FUNCTION IS TO GENERATE VALID CODES.

Requirements .NET Framework 4.0.

DOWNLOAD .NET Framework 4.0 : http://www.microsoft.com/it-it/download/details.aspx?id=17718

By R@1n.



##########################################################################
#   0.1   -   Index
##########################################################################
01. Changes in Versions
02. Arguments
03. FAQs
04. Legal Notes
05. Thanks
##########################################################################



##########################################################################
#   01   -   Changes in Versions
##########################################################################
Version 0.1 RC 8  (29/09/2022)
* Migliorata attivazione Office.
* Aggiunta Hacktivazione Windows XP (tramite WPA).
* Fix minori.

Version 0.1 RC 7  (28/09/2022)
* Aggiunto supporto attivazione Office 2010 per Windows XP.
* Fixato un errore che non faceva risultare Office 2010 attivato.

Version 0.1 RC 6  (27/09/2022)
* Riscritto algoritmo di attivazione Office.
* Risolto un problema che faceva installare una licenza office 2016 su versioni superiori.
* Risolto un problema con la visualizzazione delle immagini in una picturbox che riguardava i loghi oem.

Version 0.1 RC 5  (19/09/2022)
* Risolto un conflitto con l'identificazione dell'ID corretto per Office.

Version 0.1 RC 4  (18/09/2022)
* Fixato un errore con la conversione di chiavi quando facevi il dump delle informazioni oem
* il dump delle informazioni oem adesso accetta anche tavole msdm
* Aggiunto metodo cosmetico di verificare il successo o il fallimento in Lite Mode
* Ora viene skippato anche il controllo nella scheda keygen

Version 0.1 RC 3  (17/09/2022)
* Fixato un errore quando il keygen provava a generare una chiave per office

Version 0.1 RC 2  (16/09/2022)
* Aggiunta possibilità di skippare la verifica delle chiavi, ci puoi guadagnare qualche secondo.
* Aggiunto /SkipKeyValidityCheck
* Fixato un problema che non permetteva l'attivazione con le copie di office c2r

Version 0.1 RC 1  (15/09/2022)
* corretti alcuni problemi con keygen quando provavo a generare chiavi per VisualStudio 2022
* Aggiunti nuovi parametri per preattivazioni
* fixato un problema di riconoscimento firmware legacy/uefi

Version 0.1 Beta 3  (12/09/2022)
* corretti alcuni problemi con colori form
* aggiunto checkbox advanced, aggiunge / rimuove scheda keygen e adv

Version 0.1 Beta 2 (11/09/2022)
* Aggiunta scheda Logos

Version 0.1 Beta 1 (10/09/2022)
* Prima Release pubblica



##########################################################################
#   02   -   Arguments / Debug / Pre-Activation
##########################################################################
/ActAuto
 activate windows and office at the same time.

/ActWindows
 Activate Windows only.

/ActOffice
 Activate Office only.

/SkipKeyValidityCheck
 Skip Key Validity Check

/ForceAct
 Try to activate Windows even if it is already permanently activated.

/ForceInjectKMS
 Try to inject the KMS service even if it is already injected.

/ForceInjectLoader
 Try to inject the Loader even if it is already injected.

/PriorityKMS
 Whenever possible, it proceeds with Windows KMS Activation.

/PriorityHWID
 If you are online, and you are using a Windows 10 Client version or higher, it proceeds with Windows HWID Activation.

/PriorityOEM
 Whenever possible, it proceeds with Windows OEM:SLP Activation.

/KMSIP=
 you can customize the IP address for kms activation. (eg. /KMSIP=127.0.0.2)

/KMSPORT=
 you can customize the PORT address for kms activation. (eg. /KMSPORT=1689)

/RestorePoint
 Create a restore point before using the ReBirth.

/Logo=
 you can install custom OEM logo. You can use the associated logo pack. (default /Logo=AutoDetect)



##########################################################################
# 02 - FAQs
##########################################################################
0. Windows Update:
Q: Can I install Microsoft updates after using this program?
A: When it will be available.

1. Permanent activation:
Q: This program makes the Microsoft products activated permanently?
A: NO, even if the key is genuine, it depends on the microsoft servers.

2. Virus:
Q: My antivirus seems crazy!
A: If you downloaded the file from another site, we do not know what they could have done more. Files downloaded from our website are false positives.

3. On-line / Off-line:
Q: Do I need an internet connection to use the program?
A: No, but having an active connection can access the automatic updates and communications.

4. Product is not active:
Q: I used the program, but my product is not active, why?
A: The reasons may be varied, for simplicity, you must have a Microsoft license.



##########################################################################
# 03 - Legal Notes
##########################################################################
DISCLAIMER: ReBirth, Microsoft Keygen.

This program was not created so that "the end user" can benefit
it without possessing the necessary licenses and original of its software.
R @ 1n, however, believes that all should have the possibility to test it and to have
a backup of your licenses.

Also, it does not justify in any way the distribution of this program,
in other words do not justify the spread at any website, or P2P
in any other public place.
I ask that these releases are not popular at all.

R @ 1n I have nothing to do with the distribution of this
program, it's all done by third parties.
According to the laws that belong to the country where I reside,
it is not my responsibility what others decide to do with
these versions. However, let it be said clearly:

"NOT condone in any way the sale or distribution
of this program, this was never my intention. "

R @ 1n assumes no responsibility for any loss of data
or any errors that may occur in using these programs.
Keep in mind that you are using a third-party solution.

Note that the use of these software are legal in most
countries outside the United States, if and only if you have a
full copy of the program - so you can use these programs
for backup purposes, and only for them. It remains to be seen how
you are struck licensing agreements with the (EULA).
They can not replace national laws, remember that.

According to the "DMCA ACT" members of the United States, you do not have
rights to circumvent a copy protection. Attention, if
are using this software in an illegal manner, the maximum penalty
that you have you are equal to that you would steal the shrinkwrapped software
in a mall. Although the basic operation of R @ 1n does not reside
in the United States, and so I'm not tied to
The laws of the United States as:

* No Electronic Theft Act
* Digital Millenium Copyright Act
* The Patriot Act
* "Other laws of the United States"

You should always buy the software you use, or in place,
use open-source programs.

This Software NOT encourages piracy, which is an act UNLAWFUL,
as well as being a lack of respect towards those who dedicate time and effort
application development.

I do not assume responsibility for improper use,
that is NOT dedicated to a vision to study educational or informative.
With this I can tell you that I dedicate myself to NOT piracy in any way,
I care only to share and investigate all forms of system and evasion.

I disagree, in any form, software piracy and NOT
responsible for a eventale inappropriate or illegal use.



##########################################################################
# 04 - Thanks
##########################################################################
Thanks to: WindowsAddict, abbodi1406, Bob65536, QAD, xinso, Hotbird64, nonosense, Nosferati87, Mikmik38, Cynecx, heldigard, Daz, Alphawaves, mxman2k, Nummer for the various source codes and the work!
Thanks to all the people who have supported the development in all its forms.

Thanks to MDL STUFF: http://forums.mydigitallife.info/

Thank you so much.
