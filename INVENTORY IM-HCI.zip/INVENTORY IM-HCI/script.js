const inventory = [];
const history = [];

// Predefined items for each category with prices and item codes
const predefinedItems = {
    coffee: [
        { name: 'Espresso', price: 50, code: '123001' },
        { name: 'Latte', price: 70, code: '123002' },
        { name: 'Cappuccino', price: 80, code: '123003' },
        { name: 'Americano', price: 60, code: '123004' },
        { name: 'Mocha', price: 75, code: '123005' }
    ],
    food: [
        { name: 'Sandwich', price: 100, code: '234001' },
        { name: 'Salad', price: 90, code: '234002' }
    ],
    desserts: [
        { name: 'Cake', price: 120, code: '345001' },
        { name: 'Brownie', price: 50, code: '345002' }
    ],
    drinks: [
        { name: 'Soda', price: 40, code: '456001' },
        { name: 'Juice', price: 45, code: '456002' }
    ]
};

let currentIndex = 0;
let currentCategory = 'coffee';
let currentPrice = 0;
let currentCode = '';

function navigate(section) {
    document.querySelectorAll('.section').forEach((el) => {
        el.classList.remove('active');
    });
    document.getElementById(`${section}-section`).classList.add('active');
}

function populateItemName() {
    currentCategory = document.getElementById('itemCategory').value;
    currentIndex = 0; // Reset index when category changes
    updateItemName();
}

function updateItemName() {
    const items = predefinedItems[currentCategory];
    const selectedItem = items[currentIndex];
    document.getElementById('itemName').value = selectedItem.name;
    currentPrice = selectedItem.price;
    currentCode = selectedItem.code;
    calculateTotal(); // Calculate the total initially
}

function nextItem() {
    const items = predefinedItems[currentCategory];
    currentIndex = (currentIndex + 1) % items.length;
    updateItemName();
}

function previousItem() {
    const items = predefinedItems[currentCategory];
    currentIndex = (currentIndex - 1 + items.length) % items.length;
    updateItemName();
}

// Calculate total based on quantity and set it automatically
function calculateTotal() {
    const equity = parseInt(document.getElementById('equity').value) || 1;
    const totalPrice = equity * currentPrice;
    document.getElementById('total').value = totalPrice; // Auto-set total based on quantity
}

function addItem() {
    const itemName = document.getElementById('itemName').value;
    const equity = parseInt(document.getElementById('equity').value) || 1;
    const total = document.getElementById('total').value;
    const category = document.getElementById('itemCategory').value;
    const dateAdded = new Date().toLocaleDateString();

    if (itemName && equity && total) {
        inventory.push({ name: itemName, category, equity, total, code: currentCode });
        history.push({ name: itemName, category, equity, total, code: currentCode, dateAdded });

        displayInventory();
        displayHistory();
        document.getElementById('status-message').textContent = 'Item added successfully!';
        clearInputs();
    } else {
        document.getElementById('status-message').textContent = 'Please fill in all fields.';
    }
}

function displayInventory() {
    const inventoryList = document.getElementById('inventory-list');
    inventoryList.innerHTML = ''; // Clear previous items

    inventory.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.category}</td>
            <td>${item.equity}</td>
            <td>${item.total}</td>
            <td>${item.code}</td>
        `;
        inventoryList.appendChild(row);
    });
}

function displayHistory() {
    const historyList = document.getElementById('history-list');
    historyList.innerHTML = ''; // Clear previous items

    history.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.category}</td>
            <td>${item.total}</td>
            <td>${item.dateAdded}</td>
            <td>${item.code}</td>
        `;
        historyList.appendChild(row);
    });
}

function toggleHistory() {
    const historySection = document.getElementById('history-section');
    historySection.style.display = historySection.style.display === 'none' ? 'block' : 'none';
}

function clearInputs() {
    document.getElementById('equity').value = '';
    document.getElementById('total').value = '';
}

// Update total when equity changes
document.getElementById('equity').addEventListener('input', calculateTotal);
